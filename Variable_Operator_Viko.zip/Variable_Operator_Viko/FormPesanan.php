<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pesanan</title>
</head>
<body>

    <h2>Toko Kelontong Maju Jaya</h2>
    <form method="POST" action="">
        <label for="barang">Pilih Barang:</label><br>
        <select id="barang" name="barang">
            <option value="Sabun Mandi">Sabun Mandi</option>
            <option value="Pasta Gigi">Pasta Gigi</option>
            <option value="Shampo">Shampo</option>
        </select><br><br>

        <label for="jumlah">Jumlah Barang:</label><br>
        <input type="number" id="jumlah" name="jumlah" required><br><br>

        <input type="submit" value="Pesan">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Mengambil input dari form
        $barang = $_POST['barang'];
        $jumlah = $_POST['jumlah'];

        echo "<p>Terima Kasih anda sudah berbelanja di Toko Kelontong Maju Jaya</p>";
        echo "<h3>Data Pesanan: </h3>";
        echo "<p><strong>Barang: </strong> $barang</p>";
        echo "<p><strong>Jumlah barang: </strong> $jumlah</p>";
    }
    ?>

</body>
</html>
