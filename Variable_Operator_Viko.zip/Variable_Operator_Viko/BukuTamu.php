<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buku Tamu</title>
</head>
<body>

    <h2>Buku Tamu</h2>
    <form method="POST" action="">
        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama" required><br><br>

        <label for="email">Alamat Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="komentar">Komentar:</label><br>
        <textarea id="komentar" name="komentar" rows="4" cols="50" required></textarea><br><br>

        <input type="submit" value="OK">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nama = ($_POST['nama']);
        $email = ($_POST['email']);
        $komentar = ($_POST['komentar']);

        echo "<h3>Data Buku Tamu:</h3>";
        echo "<p><strong>Nama:</strong> $nama</p>";
        echo "<p><strong>Alamat Email:</strong> $email</p>";
        echo "<p><strong>Komentar:</strong> $komentar</p>";
    }
    ?>

</body>
</html>
