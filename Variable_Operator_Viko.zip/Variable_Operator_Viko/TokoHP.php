<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Handphone</title>
</head>
<body>

    <h2>Toko RianPhone - Penjualan Handphone</h2>
    <form method="POST" action="">

        <label>Produk:</label><br>
        <input type="checkbox" name="produk[]" value="iPhone 14 Pro Max" data-harga="15000000"> iPhone 14 Pro Max (Rp 15,000,000)<br>
        <input type="checkbox" name="produk[]" value="Samsung Galaxy S24 Ultra" data-harga="12000000"> Samsung Galaxy S24 Ultra (Rp 12,000,000)<br>
        <input type="checkbox" name="produk[]" value="Xiaomi Poco X6 Pro" data-harga="6000000"> Xiaomi Poco X6 Pro (Rp 6,000,000)<br><br>

        <label for="id_customer">ID Customer:</label><br>
        <input type="text" id="id_customer" name="id_customer" required><br><br>

        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="alamat">Alamat:</label><br>
        <input type="text" id="alamat" name="alamat" required><br><br>

        <label>Member:</label><br>
        <input type="radio" name="member" value="Yes"> Ya<br>
        <input type="radio" name="member" value="No" checked> Tidak<br><br>

        <label for="pembayaran">Metode Pembayaran:</label><br>
        <select id="pembayaran" name="pembayaran">
            <option value="VISA">VISA</option>
            <option value="Master Card">Master Card</option>
            <option value="Debit BCA">Debit BCA</option>
        </select><br><br>

        <input type="submit" value="Proses Pesanan">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id_customer = $_POST['id_customer'];
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $alamat = $_POST['alamat'];
        $produk = isset($_POST['produk']) ? $_POST['produk'] : [];
        $member = $_POST['member'];
        $pembayaran = $_POST['pembayaran'];

        $errors = [];

        if (!is_numeric($id_customer) || empty($id_customer)) {
            $errors[] = "ID Customer harus berupa bilangan dan tidak boleh kosong.";
        }

        if (empty($nama)) {
            $errors[] = "Nama tidak boleh kosong.";
        }

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Email tidak boleh kosong dan harus sesuai dengan format email.";
        }

        if (empty($alamat)) {
            $errors[] = "Alamat tidak boleh kosong.";
        }

        if (empty($produk)) {
            $errors[] = "Pilih minimal satu produk.";
        }

        if (!empty($errors)) {
            echo "<ul>";
            foreach ($errors as $error) {
                echo "<li style='color:red;'>$error</li>";
            }
            echo "</ul>";
        } else {
            $harga_total = 0;
            foreach ($produk as $item) {
                if ($item == "iPhone 14 Pro Max") {
                    $harga_total += 15000000;
                } elseif ($item == "Samsung Galaxy S24 Ultra") {
                    $harga_total += 12000000;
                } elseif ($item == "Xiaomi Poco X6 Pro") {
                    $harga_total += 6000000;
                }
            }

            if ($member == "Yes") {
                $diskon = 0.1 * $harga_total;
                $harga_total -= $diskon;
            }

            echo "<h3>Detail Pesanan Anda:</h3>";
            echo "<p><strong>ID Customer:</strong> $id_customer</p>";
            echo "<p><strong>Nama:</strong> $nama</p>";
            echo "<p><strong>Email:</strong> $email</p>";
            echo "<p><strong>Alamat:</strong> $alamat</p>";
            echo "<p><strong>Produk yang Dipesan:</strong> " . implode(", ", $produk) . "</p>";
            echo "<p><strong>Metode Pembayaran:</strong> $pembayaran</p>";
            echo "<p><strong>Total Harga:</strong> Rp " . number_format($harga_total, 0, ',', '.') . "</p>";

            if ($member == "Yes") {
                echo "<p>Anda mendapatkan diskon 10% sebagai member.</p>";
            }

            echo "<p>Terima kasih telah melakukan pemesanan di Toko RianPhone!</p>";
        }
    }
    ?>

</body>
</html>
