<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Demo Operator</title>
</head>
<body>
    <h1>Demo Operator</h1>
    <h3>Arithmetic</h3>
    <form method="POST" action="">
        <table border="1">
            <tr>
                <td><label for="operand_kiri">Operand Kiri:</label></td>
                <td><label for="operator">Operator:</label></td>
                <td><label for="operand_kanan">Operand Kanan:</label></td>
                <td rowspan="2"><input type="submit" value="Submit"></td>
            </tr>
            <tr>
                <td><input type="number" id="operand_kiri" name="operand_kiri" required></td>
                <td>
                    <select id="operator" name="operator">
                        <option value="+">+</option>
                        <option value="-">-</option>
                        <option value="*">*</option>
                        <option value="/">/</option>
                        <option value="%">%</option>
                    </select>
                </td>
                <td><input type="number" id="operand_kanan" name="operand_kanan" required></td>
            </tr>
        </table>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $operand_kiri = $_POST['operand_kiri'];
        $operator = $_POST['operator'];
        $operand_kanan = $_POST['operand_kanan'];

        $hasil = 0;

        switch ($operator) {
            case '+':
                $hasil = $operand_kiri + $operand_kanan;
                break;
            case '-':
                $hasil = $operand_kiri - $operand_kanan;
                break;
            case '*':
                $hasil = $operand_kiri * $operand_kanan;
                break;
            case '/':
                if ($operand_kanan != 0) {
                    $hasil = $operand_kiri / $operand_kanan;
                } else {
                    $hasil = "Error: Pembagian dengan nol tidak diperbolehkan.";
                }
                break;
            case '%':
                if ($operand_kanan != 0) {
                    $hasil = $operand_kiri % $operand_kanan;
                } else {
                    $hasil = "Error: Modulus dengan nol tidak diperbolehkan.";
                }
                break;
            default:
                $hasil = "Operator tidak valid.";
                break;
        }

        // Menampilkan hasil dalam satu baris
        echo "<p>Hasil dari $operand_kiri $operator $operand_kanan = $hasil</p>";
    }
    ?>

</body>
</html>
