<!DOCTYPE html>
<html>
<head>
    <title>Program Diskon Toko</title>
</head>
<body>
    <h2>Program Diskon Toko</h2>
    <form method="POST">
        <label for="nama_barang1">Nama Barang 1:</label>
        <input type="text" id="nama_barang1" name="nama_barang1" required><br><br>

        <label for="harga_satuan1">Harga Satuan Barang 1:</label>
        <input type="number" id="harga_satuan1" name="harga_satuan1" required><br><br>

        <label for="jumlah_dibeli1">Jumlah Barang 1:</label>
        <input type="number" id="jumlah_dibeli1" name="jumlah_dibeli1" required><br><br>

        <label for="nama_barang2">Nama Barang 2:</label>
        <input type="text" id="nama_barang2" name="nama_barang2" required><br><br>

        <label for="harga_satuan2">Harga Satuan Barang 2:</label>
        <input type="number" id="harga_satuan2" name="harga_satuan2" required><br><br>

        <label for="jumlah_dibeli2">Jumlah Barang 2:</label>
        <input type="number" id="jumlah_dibeli2" name="jumlah_dibeli2" required><br><br>

        <label for="member">Apakah Anda Member?</label>
        <select id="member" name="member" required>
            <option value="yes">Ya</option>
            <option value="no">Tidak</option>
        </select><br><br>

        <input type="submit" name="submit_toko" value="Hitung Total">
    </form>

    <?php
    if (isset($_POST['submit_toko'])) {
        $barang = [
            ["nama" => $_POST['nama_barang1'], "harga_satuan" => $_POST['harga_satuan1'], "jumlah" => $_POST['jumlah_dibeli1']],
            ["nama" => $_POST['nama_barang2'], "harga_satuan" => $_POST['harga_satuan2'], "jumlah" => $_POST['jumlah_dibeli2']]
        ];

        $diskon_umum = 0.1; // Diskon umum 10%
        $diskon_member = 0.05; // Diskon tambahan untuk member
        $member = $_POST['member'] == "yes"; // true jika member, false jika bukan member

        $total_harga_semua = 0;

        foreach ($barang as $item) {
            $harga_diskon = $item["harga_satuan"] * (1 - $diskon_umum);
            $total_harga = $harga_diskon * $item["jumlah"];
            $total_harga_semua += $total_harga;

            echo "<h3>Nama Barang: " . $item["nama"] . "</h3>";
            echo "Harga Satuan (setelah diskon 10%): Rp" . $harga_diskon . "<br>";
            echo "Jumlah yang dibeli: " . $item["jumlah"] . "<br>";
            echo "Total Harga: Rp" . $total_harga . "<br><br>";
        }

        if ($member) {
            $total_harga_semua *= (1 - $diskon_member);
            echo "Diskon Member (5%): Ya<br>";
        } else {
            echo "Diskon Member (5%): Tidak<br>";
        }

        echo "<h3>Jumlah Total yang Harus Dibayar: Rp" . $total_harga_semua . "</h3>";
    }
    ?>
</body>
</html>