<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Keuntungan penjualan kaos OR</title>
</head>
<body>
	<?php
        $harga_beli = 30000;
        $harga_jual = 40000;
        $pajak = 0.10; // 10%
        $stok = 5;
		

        $total_pembelian = $harga_beli * $stok;
        $total_penjualan = $harga_jual * $stok;
        $laba_kotor = $total_penjualan - $total_pembelian;
        $laba_bersih = $laba_kotor - ($laba_kotor * $pajak);

        echo "Total Pembelian: Rp" . $total_pembelian. "<br>";
        echo "Total Penjualan: Rp" . $total_penjualan. "<br>";
        echo "Laba Kotor: Rp" . $laba_kotor. "<br>";
        echo "Laba Bersih: Rp" . $laba_bersih. "<br>";
?>

</body>
</html>