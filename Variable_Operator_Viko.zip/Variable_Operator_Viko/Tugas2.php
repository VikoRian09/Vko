<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Penjumlahan dan Pengurangan</title>
</head>
<body>
<?php
    $angka_pertama = 15;
    $angka_kedua = 45;
    $jumlah = $angka_pertama + $angka_kedua;
    $hasil_akhir = $jumlah - 100;
    $teks = 'Ketiga variabel bila dijumlah dan telah dikurangi menjadi: ';
    
    echo ($teks . $hasil_akhir);
?>
</body>
</html>