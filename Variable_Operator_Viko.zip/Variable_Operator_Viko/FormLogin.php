<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
</head>
<body>

    <h2>Form Login</h2>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username"><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br><br>

        <input type="submit" value="Submit">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Username dan password yang benar
        $username_benar = "budiman";
        $password_benar = "rahasia";

        $username_input = $_POST['username'];
        $password_input = $_POST['password'];

        if ($username_input == $username_benar && $password_input == $password_benar) {
            echo "<p>Login berhasil!</p>";
        } else {
            if ($username_input != $username_benar && $password_input != $password_benar) {
                echo "<p>Username dan password salah!</p>";
            } elseif ($username_input != $username_benar) {
                echo "<p>Username salah!</p>";
            } else {
                echo "<p>Password salah!</p>";
            }
        }
    }
    ?>

</body>
</html>
