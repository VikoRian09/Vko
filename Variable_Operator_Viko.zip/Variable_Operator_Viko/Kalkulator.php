<!DOCTYPE html>
<html>
<head>
    <title>Kalkulator Sederhana</title>
</head>
<body>
    <h2>Kalkulator Sederhana</h2>
    <form method="POST">
        <label for="bilangan1">Bilangan Pertama:</label>
        <input type="number" id="bilangan1" name="bilangan1" required><br><br>

        <label for="bilangan2">Bilangan Kedua:</label>
        <input type="number" id="bilangan2" name="bilangan2" required><br><br>

        <label for="operator">Operator:</label>
        <select id="operator" name="operator" required>
            <option value="+">+</option>
            <option value="-">-</option>
            <option value="*">*</option>
            <option value="/">/</option>
            <option value="%">%</option>
        </select><br><br>

        <input type="submit" name="submit_kalkulator" value="Hitung">
    </form>

    <?php
    if (isset($_POST['submit_kalkulator'])) {
        $bilangan1 = $_POST['bilangan1'];
        $bilangan2 = $_POST['bilangan2'];
        $operator = $_POST['operator'];

        function kalkulator($bilangan1, $bilangan2, $operator) {
            switch($operator) {
                case "+":
                    return $bilangan1 + $bilangan2;
                case "-":
                    return $bilangan1 - $bilangan2;
                case "*":
                    return $bilangan1 * $bilangan2;
                case "/":
                    return $bilangan2 != 0 ? $bilangan1 / $bilangan2 : "Kesalahan: Pembagian dengan nol tidak diperbolehkan!";
                case "%":
                    return $bilangan2 != 0 ? $bilangan1 % $bilangan2 : "Kesalahan: Modulus dengan nol tidak diperbolehkan!";
                default:
                    return "Operator tidak dikenali. Gunakan salah satu dari: +, -, *, /, %";
            }
        }

        $hasil = kalkulator($bilangan1, $bilangan2, $operator);
        echo "<h3>Hasil dari $bilangan1 $operator $bilangan2 adalah: $hasil</h3>";
    }
    ?>
</body>
</html>