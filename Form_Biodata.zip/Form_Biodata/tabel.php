<?php 
include "koneksi.php"; 

// Menjalankan query untuk mengambil data dari tabel 'biodata'
$query = mysqli_query($koneksi, "SELECT * FROM db_biodata");

// Mengecek apakah query berhasil
if (!$query) {
    die("Query gagal: " . mysqli_error($koneksi)); // Menampilkan error jika query gagal
}

// Menghitung jumlah baris dari hasil query
$jumlah = mysqli_num_rows($query); 
$c = 0; 
echo "Jumlah data ada : " . $jumlah; 
?> 

<!-- Membuat tabel untuk menampilkan data -->
<table border="1"> 
<tr> 
    <th>Nomer</th>
    <th>Nama</th> 
    <th>Alamat</th>
    <th>Usia</th>
    <th>Aksi</th>  
</tr> 

<?php 
// Mengambil data satu per satu dari hasil query
while ($row = mysqli_fetch_assoc($query)) { 
?> 
<tr> 
    <td><?php echo $c=$c+1;?></td> <!-- Increment nomor otomatis -->
    <td><?php echo $row['nama']; ?></td> 
    <td><?php echo $row['alamat']; ?></td> 
    <td><?php echo $row['usia']; ?></td> 
    <td> 
        <a href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Apakah anda yakin?')">Delete</a> 
        <a href="update.php?id=<?php echo $row['id']; ?>">Update</a> 
    </td> 
</tr> 
<?php 
} 
?> 
</table><br /> 

<!-- Link untuk input data baru -->
<a href="form.php">Input data form</a>

<?php 
// Menutup koneksi setelah selesai digunakan
mysqli_close($koneksi); 
?>
