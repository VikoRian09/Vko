<?php 
include "koneksi.php"; 

// Mengambil data dari form
$id = $_POST['id']; 
$nama = $_POST['nama']; 
$alamat = $_POST['alamat']; 
$usia = $_POST['usia']; 

// Menjalankan query untuk mengupdate data di tabel 'biodata'
$query = mysqli_query($koneksi, "UPDATE db_biodata SET nama='$nama', alamat='$alamat', usia='$usia' WHERE id='$id'");

// Mengecek apakah query berhasil
if ($query) { 
    echo "Berhasil update data ke database "; 
    echo '<a href="tabel.php">Lihat data di Tabel</a>';
} else { 
    echo "Gagal update data: " . mysqli_error($koneksi); 
} 

// Menutup koneksi
mysqli_close($koneksi); 
?>
