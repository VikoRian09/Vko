<?php 
include "koneksi.php"; 

// Mengambil id dari URL menggunakan metode GET
$id = $_GET['id']; 

// Menjalankan query untuk menghapus data dari tabel 'biodata'
$query = mysqli_query($koneksi, "DELETE FROM db_biodata WHERE id='$id'");

// Mengecek apakah query berhasil
if ($query) { 
    // Jika berhasil, redirect ke tabel.php
    echo "<script language='javascript'>document.location.href='tabel.php';</script>"; 
} else { 
    // Jika gagal, tampilkan pesan error
    echo "Gagal hapus data: " . mysqli_error($koneksi); 
} 

// Menutup koneksi
mysqli_close($koneksi); 
?>
