<?php
include "koneksi.php";

$nama = $_POST['nama'];  // Variabel diperbaiki menjadi 'nama'
$alamat = $_POST['alamat'];
$usia = $_POST['usia'];

$query = "INSERT INTO db_biodata (nama, alamat, usia) VALUES ('$nama', '$alamat', '$usia')";

if (mysqli_query($koneksi, $query)) {
    echo "Berhasil input data ke database ";
    echo '<a href="tabel.php">Lihat data di Tabel</a>';
} else {
    echo "Gagal input data: " . mysqli_error($koneksi);
}
?>