<?php 
$host = "localhost"; 
$user = "root"; 
$password = ""; 
$database = "db_biodata"; 

// Membuat koneksi ke database
$koneksi = mysqli_connect($host, $user, $password, $database);

// Mengecek koneksi
if ($koneksi) { 
    echo "Berhasil koneksi"; 
} else { 
    echo "Gagal koneksi: " . mysqli_connect_error(); 
} 
?>
