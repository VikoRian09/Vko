<?php 
include "koneksi.php"; 

// Mengambil 'id' dari URL menggunakan metode GET
$id = $_GET['id']; 

// Menjalankan query untuk mengambil data berdasarkan 'id' dari tabel 'biodata'
$query = mysqli_query($koneksi, "SELECT * FROM db_biodata WHERE id='$id'");

// Mengecek apakah query berhasil
if (!$query) {
    die("Query gagal: " . mysqli_error($koneksi));
}

?> 

<!-- Form untuk mengupdate data -->
<form action="simpan.php" method="post"> 
<table border="1"> 
<?php 
// Mengambil data dari hasil query
while ($row = mysqli_fetch_assoc($query)) { 
?> 
    <!-- Input hidden untuk menyimpan ID -->
    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
    
    <!-- Input untuk nama -->
    <tr> 
        <td>Nama</td>
        <td><input type="text" name="nama" value="<?php echo $row['nama']; ?>" /></td> 
    </tr> 
    
    <!-- Input untuk alamat -->
    <tr> 
        <td>Alamat</td> 
        <td><textarea cols="20" rows="5" name="alamat"><?php echo $row['alamat']; ?></textarea></td> 
    </tr> 
    
    <!-- Input untuk usia -->
    <tr>
        <td>Usia</td>
        <td><input type="text" name="usia" value="<?php echo $row['usia']; ?>" /></td> 
    </tr> 
    
    <!-- Tombol submit -->
    <tr>
        <td colspan="2"><input type="submit" value="Simpan" name="simpan" /></td> 
    </tr> 
<?php 
} 
?> 
</table> 
</form>

<?php 
// Menutup koneksi setelah selesai digunakan
mysqli_close($koneksi); 
?>
