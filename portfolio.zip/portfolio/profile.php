<?php include('includes/db.php'); ?> 
<?php 
session_start(); 
if (!isset($_SESSION['username'])) { 
header('Location: login.php'); 
exit(); 
} 
$username = $_SESSION['username']; 
$sql = "SELECT * FROM portfolio_users WHERE username='$username'"; 
$result = $conn->query($sql); 
$user = $result->fetch_assoc(); 
?> 
<h2>Profile</h2> 
<p>Username: <?php echo $user['username']; ?></p> 
<p>Email: <?php echo $user['email']; ?></p> 
<a href="admin/manage_project.php">Manage Projects</a> | 
<a href="admin/logout.php">Logout</a> 
