<?php include('includes/header.php'); ?> 
<?php include('includes/db.php'); ?> 
<h2>Login</h2> 
<form action="" method="POST"> 
<label for="username">Username:</label> 
<input type="text" id="username" name="username" required> 
<br> 
<label for="password">Password:</label> 
<input type="password" id="password" name="password" required> 
<br> 
<input type="submit" name="login" value="Login"> 
</form> 
<?php 
session_start(); 
 
if (isset($_POST['login'])) { 
    $username = $_POST['username']; 
    $password = md5($_POST['password']); 
 
    $sql = "SELECT * FROM portfolio_users WHERE username='$username'"; 
    $result = $conn->query($sql); 
 
    if ($result->num_rows > 0) { 
        $row = $result->fetch_assoc(); 
        if (md5($password, $row['password'])) { 
            $_SESSION['username'] = $username; 
            header('Location: profile.php'); 
        } else { 
            echo "Invalid password!"; 
        } 
    } else { 
        echo "No user found!"; 
    } 
} 
?> 
 
<?php include('includes/footer.php'); ?> 