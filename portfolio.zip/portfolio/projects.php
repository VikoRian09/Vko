<?php include('includes/header.php'); ?> 
<?php include('includes/db.php'); ?> 
<h2>Projects</h2> 
<?php include('includes/footer.php'); ?> 